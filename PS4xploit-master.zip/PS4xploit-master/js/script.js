let dde = document.documentElement;
dde.addEventListener("mousemove", e => {
  let ow = dde.offsetWidth; 
  let oh = dde.offsetHeight; 
  dde.style.setProperty('--mouseX', e.clientX * 100 / ow + "%");
  dde.style.setProperty('--mouseY', e.clientY * 100 / oh + "%");
});

function isInArray(value, array) {
  return array.indexOf(value) > -1;
}

function updatePage(title, header, buttons) {
  document.title = "HAKKURAIFU | PS4 Exploit Host";
  document.getElementById("title").innerHTML = title;
  document.getElementById("header").innerHTML = header;
  document.getElementById("buttons").innerHTML = buttons;
}

function resetPage() {
  history.pushState("", document.title, window.location.pathname + window.location.search);
  updatePage("HAKKURAIFU | PS4 Exploit Host", "Choose Firmware", firmwares);
}

function getFirmwares() {
  var firmwareSpoofs = {
    "5.51": "4.55",
    "5.07": "5.05"
  };
  var ua = navigator.userAgent;
  var currentFirmware = ua.substring(ua.indexOf("5.0 (") + 19, ua.indexOf(") Apple"));
  if (firmwareSpoofs.hasOwnProperty(currentFirmware)) {
    currentFirmware = firmwareSpoofs[currentFirmware];
  }
  var firmwares = "";
  x = 0;
  for (var i = 0, len = data["Choose Firmware"].length; i < len; i++) {
    x += 1;
    if (currentFirmware == data["Choose Firmware"][i]) {
      firmwares += "<a href=\"#" + data["Choose Firmware"][i] + "\"><button class=\"btn btn-main\">" + data["Choose Firmware"][i] + "</button></a>";
    } else {
      firmwares += "<a href=\"#" + data["Choose Firmware"][i] + "\"><button class=\"btn btn-disabled\">" + data["Choose Firmware"][i] + "</button></a>";
    }
    if (x >= 3) {
      firmwares += "<br>";
      x = 0;
    }
  }
  // similar behavior as clicking on a link
  window.location.href = ".#" + currentFirmware;

  
  return firmwares;
}

function getExploits() {
  var hash = window.location.hash.substr(1);
  var exploits = "";
  x = 0;
  for (var i = 0, len = data[hash].length; i < len; i++) {
    x += 1;
    if (data[hash][i] == "[Back]") {
      exploits += "<a href=\"#back\"><button class=\"btn btn-main\">" + data[hash][i] + "</button></a>";
    } else {
      exploits += "<a href=\"."  + exploitBase + "FirmwareExploit/" + hash + "/" + data[hash][i] + "/index.html\"><button class=\"btn btn-main\">" + data[hash][i] + "</button></a>";
    }
    if (x >= 3) {
      exploits += "<br>";
      x = 0;
    }
  }
  return exploits;
}

function firmwareSelected() {
  var hash = window.location.hash.substr(1);
  if (!isInArray(hash, firmwares)) {
    resetPage();
  } else {
    var exploits = getExploits();
    updatePage("Firmware Exploit | " + hash, hash, exploits);
  }
}

